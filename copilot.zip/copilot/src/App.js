import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomeQuerySearch from "./pages/HomeQuerySearch";
import CssBaseline from "@mui/material/CssBaseline";
import Container from "@mui/material/Container";
import SearchedQueries from "./pages/SearchedQueries";
import StyledEngineProvider from "@mui/material/StyledEngineProvider";

const MainContent = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomeQuerySearch />} />
        <Route path="/SearchedQuery" element={<SearchedQueries />} />
      </Routes>
    </Router>
  );
};

function App() {
  return (
    <StyledEngineProvider injectFirst>
    <div className="App">
      <CssBaseline />
      <Container
        maxWidth="md"
      >
        <MainContent />
      </Container>
    </div>
    </StyledEngineProvider>
  );
}

export default App;

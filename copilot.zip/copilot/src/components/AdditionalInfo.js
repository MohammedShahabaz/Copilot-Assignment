import React from "react";
import Accordian from "././Accordian";
import { Box, Typography, Grid, Button } from "@mui/material";
import CloudCircleRoundedIcon from "@mui/icons-material/CloudCircleRounded";
import PieChart from "././PieChart";
import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";
import MoreInformation from "./MoreInformation";
import "../styles/additionalInfo.css";

const TitleInfo = ({ title }) => {
  return (
    <Box className="titleContainer">
      <CloudCircleRoundedIcon fontSize="medium" />
      <Typography className="title" color="text.secondary">
        {title}
      </Typography>
    </Box>
  );
};

export default function AdditionalInfo({ data }) {
  return (
    <Grid item>
      <Accordian
        summary={<TitleInfo title={data.additionalText} />}
        actions={
          <Button
            size="small"
            className="button"
            startIcon={<ContentCopyRoundedIcon />}
          >
            Add to Dashboard
          </Button>
        }
      >
        {data.pieChartData && <PieChart />}
        {data.moreInfo && <MoreInformation />}
        {data.dashboardData && <PieChart />}
      </Accordian>
    </Grid>
  );
}

import React from "react";
import { Chart } from "react-google-charts";

export const data = [
  ["Task", "Hours per Day"],
  ["EC2", 30],
  ["RDS", 20],
  ["S3", 20],
  ["Opensearch", 10],
  ["Elasticcache", 10], // CSS-style declaration
  ["others", 10], 
];

export const options = {
  title: "Cloud cost by services",
  pieHole: 0.4,
  is3D: false,
};

export default function PieChart() {
  return (
    <Chart
      chartType="PieChart"
      width="100%"
      height="300px"
      data={data}
      options={options}
    />
  );
}

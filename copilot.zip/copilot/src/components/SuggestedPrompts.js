import React from "react";
import {
  Grid,
  Card,
  Typography,
  CardActionArea,
  CardContent,
} from "@mui/material";
import {useNavigate} from "react-router-dom";


const Prompt = ({ promptData ,onPromptClick,isDisabled }) => {

  return (
    <Grid item xs={12} sm={6}>
      <Card variant="outlined" sx={{ borderRadius: "10px",background: isDisabled ? "#eeeeee" : "none" }}>
        <CardActionArea onClick={()=>onPromptClick(promptData.id)} disabled={isDisabled}>
          <CardContent>
            <Typography fontSize={12} color="text.secondary">
              {promptData.prompt}
            </Typography>
          </CardContent>
        </CardActionArea>
      </Card>
    </Grid>
  );
};

export default function SuggestedPrompts({ prompts }) {
  const navigate = useNavigate();
  
  const handleClick = (id) =>{
      navigate("/SearchedQuery", {
        state: { promptId :id}
      });
  }

  return (
    <Grid container spacing={2} mb={2}>
      {prompts.map((item) => (
        <Prompt promptData={item} key={item.id} onPromptClick={handleClick} isDisabled={item.isDisabled}/>
      ))}
    </Grid>
  );
}

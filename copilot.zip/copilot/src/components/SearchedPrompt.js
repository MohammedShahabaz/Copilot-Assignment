import React from "react";
import AccountBoxRoundedIcon from '@mui/icons-material/AccountBoxRounded';
import {Typography,Box} from "@mui/material";
import { Grid } from "@mui/material";

export default function SearchedPrompt({ searchedPrompt }) {
  return (
    <Grid item>
    <Box sx={{padding:"10px", borderRadius: "10px",display:'flex',flexDirection:'row',justifyContent:'flex-start',alignItems:'center',backgroundColor: "#F5F5F6" }}>
        <AccountBoxRoundedIcon fontSize="medium"/>
        <Typography sx={{ fontSize: 14,marginLeft:"10px",color:'#424242' }} color="text.secondary">
          {searchedPrompt}
        </Typography>
    </Box>
    </Grid>
  );
}

import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";
import { useEffect, useRef } from "react";
import { Grid, Typography, Button } from "@mui/material";
import hljs from "highlight.js/lib/core";
import javascript from "highlight.js/lib/languages/javascript";
import "highlight.js/styles/monokai.css";
import Accordian from "./Accordian";
import "../styles/additionalInfo.css";

hljs.registerLanguage("javascript", javascript);

const CodeSnippet = () => {
  const codeRef = useRef(null);

  useEffect(() => {
    hljs.highlightBlock(codeRef.current);
  }, []);

  return (
    <Grid item>
      <Accordian
        summary={
          <Typography fontSize={12} color="text.secondary">
            Query
          </Typography>
        }
        actions={
          <Button
            size="small"
            className="button"
            startIcon={<ContentCopyRoundedIcon />}
          >
            Copy Query
          </Button>
        }
      >
        <pre className="preTag">
          <code className="javascript code" ref={codeRef}>
            {`
              SELECT
              service,
              SUM(cost) AS total_cost
              FROM
              cloud_costs
              WHERE
              account_type = 'production (#24542)'
              GROUP BY
              service
              ORDER BY
              total_cost DESC;
            `}
          </code>
        </pre>
      </Accordian>
    </Grid>
  );
};

export default CodeSnippet;

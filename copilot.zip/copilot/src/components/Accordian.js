import * as React from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  AccordionActions,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import "../styles/accordian.css";

export default function AccordionExpandDefault({ summary, children, actions }) {
  return (
    <Accordion defaultExpanded disableGutters>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon fontSize="small" />}
        aria-controls="panel1-content"
        id="panel1-header"
        className="summary"
      >
        {summary}
      </AccordionSummary>
      <AccordionDetails className="details">{children}</AccordionDetails>
      <AccordionActions>{actions}</AccordionActions>
    </Accordion>
  );
}

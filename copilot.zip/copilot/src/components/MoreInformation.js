import React from "react";
import { Typography, Box } from "@mui/material";

const SomeStuff = () => {
  return (
    <Box sx={{ ...boxStyle }}>
      <Typography sx={{ ...typographyStyle }}>
        Bucket xyz-logs-1 production account
      </Typography>
      <Typography sx={{ fontSize: 12, color: "black", textAlign: "start" }}>
        This bucket has 1 TB of data and it does not use any storage tiers This
        bucket has 1 TB of data and it does not use any storage tiers This
        bucket has 1 TB of data and it does not use any storage tiers
      </Typography>
    </Box>
  );
};
export default function MoreInformation() {
  return (
    <Box>
      <SomeStuff />
      <SomeStuff />
    </Box>
  );
}

const boxStyle = {
    padding: "10px",
    border: "1px solid green",
    borderRadius: "10px",
    margin: "10px",
  };
  
  const typographyStyle = {
    fontWeight: 600,
    fontSize: 12,
    color: "black",
    textAlign: "start",
    marginBottom: "5px",
  };
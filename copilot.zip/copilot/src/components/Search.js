import React from "react";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import IconButton from "@mui/material/IconButton";
import CodeIcon from "@mui/icons-material/Code";
import SendOutlinedIcon from "@mui/icons-material/SendOutlined";
import "../styles/search.css"; 

export default function CustomizedInputBase() {
  return (
    <Paper
      component="form"
      elevation={8}
      className="customized-input-base" 
    >
      <InputBase
        className="input-base" 
        placeholder="Start typing your query here..."
        inputProps={{ "aria-label": "search google maps" }}
      />
      <IconButton className="icon-button" aria-label="search">
        <CodeIcon />
      </IconButton>
      <IconButton className="icon-button" aria-label="directions">
        <SendOutlinedIcon />
      </IconButton>
    </Paper>
  );
}

import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import jsonData from "../data.json";
import SearchedPrompt from "../components/SearchedPrompt";
import { Grid, Typography, Box } from "@mui/material";
import CodeSnippet from "../components/CodeSnippet";
import AdditionalInfo from "../components/AdditionalInfo";
import Accordian from "../components/Accordian";
import SuggestedPrompts from "../components/SuggestedPrompts";
import CustomizedInputBase from "../components/Search";
import "../styles/home.css";

export default function SearchedQueries() {
  const [searchedQueries, setSearchedQueries] = useState([]);
  const newItemRef = useRef(null);
  const location = useLocation();
  const { promptId } = location.state || {};

  useEffect(() => {
    setSearchedQueries((prevState) => {
      return [...prevState, jsonData.find((obj) => obj.promptId === promptId)];
    });
  }, [promptId]);

  useEffect(() => {
    if (newItemRef.current) {
      newItemRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [searchedQueries]);

  return (
    <>
      <Box mb={8}>
        {searchedQueries.length &&
          searchedQueries.map((query) => (
            <Grid container direction={"column"} key={query.promptId} rowGap={2} pt={1}
              ref={query.promptId === searchedQueries[searchedQueries.length - 1].promptId? newItemRef: null}
            >
              <SearchedPrompt
                searchedPrompt={query.prompt}
                key={query.promptId}
              />
              {query.queryData && <CodeSnippet />}
              <AdditionalInfo data={query.additionalData} />
              {query.suggestedPrompts && (
                <Accordian
                  summary={
                    <Typography className="title" color="text.secondary">
                      You might also want to know
                    </Typography>
                  }
                >
                  <SuggestedPrompts prompts={query.suggestedPrompts.prompts} />
                </Accordian>
              )}
            </Grid>
          ))}
      </Box>
      <Box className="box-container">
        <CustomizedInputBase />
      </Box>
    </>
  );
}

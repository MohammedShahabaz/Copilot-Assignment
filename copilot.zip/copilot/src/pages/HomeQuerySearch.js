import React from "react";
import SuggestedPrompts from "../components/SuggestedPrompts";
import defaultPrompts from "../default.json";
import CustomizedInputBase from "../components/Search";
import { Box } from "@mui/material";
import "../styles/home.css";

export default function HomeQuerySearch() {
  return (
    <Box className="container">
      <SuggestedPrompts prompts={defaultPrompts} />
      <CustomizedInputBase />
    </Box>
  );
}
